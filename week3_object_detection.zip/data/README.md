# Test Data Directory

This directory holds evaluation frames and annotations for testing and benchmarking the detector.

## Structure

```
data/
├── raw/              # Original CCTV-style source footage (not committed)
├── frames/           # Extracted evaluation frames (PNG/JPG)
└── annotations/      # Ground-truth bounding boxes (JSON/YOLO format)
```

## Evaluation Frame Format

Each frame in `frames/` should be named: `frame_001.jpg`, `frame_002.jpg`, etc.

## Annotation Format

YOLO format: `frame_001.txt`
```
<class_id> <x_center> <y_center> <width> <height>
```
Where coordinates are normalized to [0, 1].

Example:
```
0 0.45 0.50 0.20 0.30
2 0.70 0.60 0.15 0.25
```

Or JSON format: `frame_001.json`
```json
[
  {"x1": 100, "y1": 120, "x2": 200, "y2": 300, "class_id": 0, "class_name": "person"},
  {"x1": 250, "y1": 150, "x2": 350, "y2": 400, "class_id": 2, "class_name": "car"}
]
```

## Sources

- **Public footage:** https://www.youtube.com/watch?v=... (verify usage rights)
- **Authorized CCTV:** Obtain permission before use
- **Synthetic data:** Generate with Blender or similar

## Usage Rights

**IMPORTANT:** Never commit private or unauthorized footage.

Before adding:
1. Verify usage rights (CC BY, public domain, etc.)
2. Document source URL & license
3. Note date accessed
4. Confirm no personally identifiable information (PII)

## Provenance Template

Create `data/SOURCES.md`:
```markdown
## Data Sources

### frame_001–frame_010 (Person dataset)
- Source: [Public CCTV compilation](https://link-to-video)
- License: CC BY 4.0
- Date accessed: 2026-09-08
- Annotation: Manual, 50 boxes total
- Classes: person, bicycle
```
