# tests/test_evaluation.py - Evaluation metrics tests
import pytest
from evaluation import EvaluationMetrics

class TestEvaluationMetrics:
    def test_perfect_detection(self):
        gt = [{'x1': 10, 'y1': 10, 'x2': 50, 'y2': 50, 'class_id': 0}]
        pred = [{'x1': 10, 'y1': 10, 'x2': 50, 'y2': 50, 'class_id': 0, 'confidence': 0.9}]
        
        metrics = EvaluationMetrics(iou_threshold=0.5)
        tp, fp, fn = metrics.match_boxes(gt, pred)
        assert tp == 1 and fp == 0 and fn == 0
    
    def test_false_positive(self):
        gt = []
        pred = [{'x1': 10, 'y1': 10, 'x2': 50, 'y2': 50, 'class_id': 0, 'confidence': 0.9}]
        
        metrics = EvaluationMetrics(iou_threshold=0.5)
        tp, fp, fn = metrics.match_boxes(gt, pred)
        assert tp == 0 and fp == 1 and fn == 0
    
    def test_false_negative(self):
        gt = [{'x1': 10, 'y1': 10, 'x2': 50, 'y2': 50, 'class_id': 0}]
        pred = []
        
        metrics = EvaluationMetrics(iou_threshold=0.5)
        tp, fp, fn = metrics.match_boxes(gt, pred)
        assert tp == 0 and fp == 0 and fn == 1
    
    def test_no_overlap_missed(self):
        gt = [{'x1': 10, 'y1': 10, 'x2': 50, 'y2': 50, 'class_id': 0}]
        pred = [{'x1': 100, 'y1': 100, 'x2': 150, 'y2': 150, 'class_id': 0, 'confidence': 0.9}]
        
        metrics = EvaluationMetrics(iou_threshold=0.5)
        tp, fp, fn = metrics.match_boxes(gt, pred)
        assert tp == 0 and fp == 1 and fn == 1
    
    def test_calculate_metrics_division_by_zero(self):
        metrics = EvaluationMetrics()
        result = metrics.calculate_metrics(0, 0, 0)
        assert result['precision'] == 0.0
        assert result['recall'] == 0.0
        assert result['f1'] == 0.0
    
    def test_calculate_metrics_normal(self):
        metrics = EvaluationMetrics()
        result = metrics.calculate_metrics(8, 2, 0)
        assert result['precision'] == 0.8
        assert result['recall'] == 1.0
        assert result['f1'] > 0.8

if __name__ == "__main__":
    pytest.main([__file__, "-v"])
