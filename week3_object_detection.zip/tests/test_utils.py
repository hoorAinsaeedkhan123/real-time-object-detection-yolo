# tests/test_utils.py - Unit tests for utils
import pytest
from utils import (sanitize_filename, format_timestamp, validate_coordinates, 
                   calculate_iou, generate_safe_path)

class TestSanitization:
    def test_sanitize_filename_basic(self):
        result = sanitize_filename("my_video.mp4")
        assert result == "my_video.mp4"
    
    def test_sanitize_filename_special_chars(self):
        result = sanitize_filename("my@#$%video^.mp4")
        assert "$" not in result and "@" not in result
    
    def test_sanitize_filename_preserves_ext(self):
        result = sanitize_filename("video.MP4")
        assert result.endswith(".mp4")  # Extension is lowercased

class TestTimestamp:
    def test_format_timestamp_zero(self):
        ts_sec, ts_text = format_timestamp(0, 30)
        assert ts_sec == 0.0
        assert ts_text == "00:00:00"
    
    def test_format_timestamp_basic(self):
        ts_sec, ts_text = format_timestamp(30, 30)
        assert ts_sec == 1.0
        assert ts_text == "00:00:01"
    
    def test_format_timestamp_hours(self):
        ts_sec, ts_text = format_timestamp(3600 * 30, 30)
        assert ts_sec == 3600
        assert ts_text == "01:00:00"
    
    def test_format_timestamp_zero_fps(self):
        ts_sec, ts_text = format_timestamp(100, 0)
        assert ts_sec == 0.0
        assert ts_text == "00:00:00"

class TestCoordinateValidation:
    def test_valid_box(self):
        assert validate_coordinates(10, 10, 50, 50, 100, 100) == True
    
    def test_invalid_negative(self):
        assert validate_coordinates(-1, 10, 50, 50, 100, 100) == False
    
    def test_invalid_out_of_bounds(self):
        assert validate_coordinates(10, 10, 150, 150, 100, 100) == False
    
    def test_invalid_inverted(self):
        assert validate_coordinates(50, 50, 10, 10, 100, 100) == False

class TestIoU:
    def test_iou_perfect_overlap(self):
        iou = calculate_iou((0, 0, 10, 10), (0, 0, 10, 10))
        assert iou == pytest.approx(1.0, abs=0.01)
    
    def test_iou_no_overlap(self):
        iou = calculate_iou((0, 0, 10, 10), (20, 20, 30, 30))
        assert iou == 0.0
    
    def test_iou_partial_overlap(self):
        iou = calculate_iou((0, 0, 10, 10), (5, 5, 15, 15))
        assert 0 < iou < 1
        assert iou == pytest.approx(0.14286, abs=0.01)

if __name__ == "__main__":
    pytest.main([__file__, "-v"])
